# Fusion OS Build Kit (Debian Trixie)

## Included Features
- **Dual-Boot Ready:** Graphical Debian Live Installer (`--debian-installer-gui true`), `os-prober` enabled (`GRUB_DISABLE_OS_PROBER=false`), UEFI + BIOS GRUB packages, NTFS/exFAT support, and KDE Partition Manager / GParted for resizing Windows partitions safely.
- **Multi-Language Packs:** `locales-all`, Noto universal fonts (Devanagari, CJK, Arabic, Emoji), Hindi desktop tasks (`task-hindi-desktop`), and `ibus` + `ibus-m17n` keyboard input methods.
- **Linux Apps:** Native APT, Flatpak (Flathub preconfigured), and AppImage (`libfuse2t64`).
- **Windows Apps (`.exe` / `.msi`):** Wine (64-bit & 32-bit), Winetricks, Vulkan drivers, and Bottles.
- **Android Apps (`.apk`):** KDE Plasma on Wayland + Waydroid pre-installed (run `sudo waydroid init` on first boot).

## How to Build
1. Upload the contents of this archive to the root of your `main` branch on GitHub.
2. Open the **Actions** tab and run **Build Fusion OS ISO**.
3. Download the `fusion-os-live-iso` artifact once the build completes.
